package Salary_Management;

public class CompanyBasics 
{
    private String name, rank; 									// 이름, 직급
    private int normal, extrapay; 								// 기본급, 수당
    private double tariff, salary; 								// 세율, 월급
    
    public String getName() { return name; } 					// 이름 받아오기
    public void setName(String name) { this.name = name; }		// 이름 지정하기
    
    public String getRank() { return rank; }					// 직급 받아오기
    public void setRank(String rank) { this.rank = rank; }		// 직급 지정하기
    
    public int getNormal() { return normal; }					// 기본급 받아오기
    public void setNormal(int normal) { this.normal = normal;}	// 기본급 지정하기
    
    public int getExtrapay() { return extrapay; }					// 수당 받아오기
    public void setExtrapay(int extrapay) {this.extrapay=extrapay;}	// 수당 지정하기
    
    public double getTariff() { return tariff; }					// 세율 받아오기
    public void setTariff(double tariff) { this.tariff = tariff;}	// 세율 지정하기
    
    public double getSalary() { return salary; }					// 월급 받아오기
    public void setSalary(double salary) { this.salary = salary;}	// 월급 지정하기
    
    // toString을 오버라이드 해주지 않으면
    // 저장된 객체의 주소가 출력된다.
    @Override
    public String toString() 
    {
        return "이름 : " + this.getName() +
                ", 직급 : " + this.getRank() +
                ", 기본급 : " + this.getNormal() + "만원" +
                ", 수당 : " + this.getExtrapay() + "만원" +
                ", 세율 : " + (int)(this.getTariff()*100) + "%" +
                ", 월급 : " + this.getSalary() +"만원" ; 
    }
}