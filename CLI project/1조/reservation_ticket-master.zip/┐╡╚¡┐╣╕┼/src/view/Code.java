package view;

public interface Code {

	// 상수 정의, 숫자는 메뉴 번호
		static final int USER_LOGIN = 999; //로그인
		
		static final int SEAT_LIST = 111; //좌석목록
		
		
		static final int MAIN_MENU = 199; // 메인
		static final int USER_MENU = 200;
		static final int USER_JOIN = 201; //회원가입
		static final int USER_MENU_LOGIN = 299; //회원 로그인
		
		
		static final int USER_TICKET_LIST = 220; //영화예매 리스트
		static final int USER_TICKET_ADD = 221; //영화예매 하기
		static final int USER_TICKET_DEL = 222; //영화예매 취소
		
}
