package service;

public interface User {
	
	void ticketList(); //영화예매 리스트
	void ticketAdd(); //영화예매 하기
	void ticketRemove(); //영화예매 취소

}
