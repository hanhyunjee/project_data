package service;

public interface Seat {

	public void seatList(); //좌석현황
}
