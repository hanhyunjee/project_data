# Java console project
## 영화예매

<img width="572" alt="Screen Shot 2022-03-08 at 5 48 54 PM" src="https://user-images.githubusercontent.com/91236026/157200993-4ddcb368-ec1c-4202-ad4c-b3200a00809e.png">
