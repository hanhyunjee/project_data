package BookManage;
public class ManagerMain {
	public static void main(String[] args) {
		BookManager book = new BookManager();
		book.inputLogin();
//맨처음은 로그인 화면으로 이동		

	}

}
